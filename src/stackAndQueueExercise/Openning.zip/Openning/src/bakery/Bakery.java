package Openning.src.bakery;

import java.util.ArrayList;
import java.util.List;

public class Bakery {

    private String name;
    private int capacity;
    private List<Employee> employees;

    public Bakery(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        employees = new ArrayList<>();
    }

    public void add(Employee employee){
        if(this.employees.size() < this.capacity){
            this.employees.add(employee);
        }
    }

    public boolean remove(String name){
        return employees.removeIf(employee -> employee.getName().equals(name));
    }

    public Employee getOldestEmployee(){
        return this.employees.stream()
                .sorted((l, r) -> Integer.compare(r.getAge(), l.getAge()))
                .findFirst().get();
    }

    public Employee getEmployee(String name){
        for (Employee e : employees) {
            if(e.getName().equals(name)){
                return e;
            }
        }
        return null;
    }

    public int getCount(){
        return this.employees.size();
    }

    public String report(){
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Employees working at Bakery %s:%n",this.name));

        for (Employee employee : employees) {
            sb.append(String.format("%s%n",employee.toString()));
        }
        return sb.toString();
    }
}
